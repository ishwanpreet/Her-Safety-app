# SheSafe 🛡️

SheSafe is a **web-based women’s safety platform** designed to provide **instant help in critical situations**. It focuses on speed, simplicity, and accessibility—because when seconds matter, safety tools shouldn’t be complicated.

---

## 🚨 Problem Statement

In emergency or uncomfortable situations, many safety apps are too slow, complex, or difficult to access discreetly. Users often need multiple steps to trigger help, which is unrealistic under stress.

**SheSafe solves this by enabling one-tap emergency actions and discreet escape tools.**

---

## ✨ Features

* **Instant Emergency Alerts**
  Trigger an alert immediately to notify trusted contacts.

* **Live Location Sharing**
  Share real-time location with selected contacts for continuous tracking.

* **Discreet Escape Tools**
  Fake call functionality to help users exit unsafe situations without drawing attention.

* **Fast & Intuitive UI**
  Minimal steps, clean interface, and mobile-first design.

* **Web-Based & Accessible**
  No app installation required—works across devices.

---

## 🧠 Design Principles

* **Speed over complexity** – actions should take seconds, not minutes
* **Discretion** – safety without attracting attention
* **Accessibility** – usable by anyone, anywhere
* **Reliability** – works under stress and poor conditions

---

## 🛠️ Tech Stack

**Frontend**

* React
* Tailwind CSS
* JavaScript

**Backend / Services**

* Firebase (Authentication, Realtime Database)
* Geolocation APIs

---

## 🧩 System Workflow

1. User logs in securely
2. Adds trusted emergency contacts
3. Enables location access
4. In an unsafe situation:

   * Triggers emergency alert **OR**
   * Activates fake call feature
5. Contacts receive alerts and live location updates

---

## 🔒 Privacy & Safety

* No public location sharing
* User-controlled contact list
* Location shared only during emergencies
* Minimal data storage

---

## 🚀 Getting Started

### Prerequisites

* Node.js
* npm or yarn

### Installation

```bash
npm install
npm start


##  Future Enhancements
* SMS alerts for low-internet scenarios
* SOS wearable integration
* Community safety heatmaps
* Voice-activated emergency triggers
* Anonymous incident reporting

SheSafe – because safety should be simple, fast, and always accessible.
