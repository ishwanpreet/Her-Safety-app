// App constants
export const APP_NAME = 'SheSafe';
export const APP_VERSION = '1.0.0';

// Location update interval (2 minutes in milliseconds)
export const LOCATION_UPDATE_INTERVAL = 120000;

// Default location (Los Angeles)
export const DEFAULT_LOCATION = {
  lat: 34.0522,
  lng: -118.2437
};

// Severity levels
export const SEVERITY_LEVELS = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high'
};

// Unsafe area reasons
export const UNSAFE_REASONS = [
  { value: 'poor_lighting', label: 'Poor lighting' },
  { value: 'isolated', label: 'Isolated area' },
  { value: 'harassment', label: 'Harassment/catcalling' },
  { value: 'suspicious_activity', label: 'Suspicious activity' },
  { value: 'no_people', label: 'No people around' },
  { value: 'other', label: 'Other' }
];

// Storage keys
export const STORAGE_KEYS = {
  USER: 'shesafe_user',
  CONTACTS: 'contacts_',
  SAFETY_PINS: 'safety_pins'
};