/**
 * Get color class for severity level
 */
export const getSeverityColor = (severity) => {
  switch(severity) {
    case 'high': 
      return 'text-red-600';
    case 'medium': 
      return 'text-orange-600';
    case 'low': 
      return 'text-yellow-600';
    default: 
      return 'text-gray-600';
  }
};

/**
 * Get background color class for severity level
 */
export const getSeverityBg = (severity) => {
  switch(severity) {
    case 'high': 
      return 'bg-red-100';
    case 'medium': 
      return 'bg-orange-100';
    case 'low': 
      return 'bg-yellow-100';
    default: 
      return 'bg-gray-100';
  }
};

/**
 * Calculate statistics for heatmap pins by severity
 */
export const getHeatmapStats = (pins) => {
  return pins.reduce((acc, pin) => {
    acc[pin.severity] = (acc[pin.severity] || 0) + 1;
    return acc;
  }, {});
};

/**
 * Format seconds into MM:SS format
 */
export const formatTime = (seconds) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${String(secs).padStart(2, '0')}`;
};

/**
 * Format date to readable string
 */
export const formatDate = (timestamp) => {
  const date = new Date(timestamp);
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

/**
 * Generate Google Maps link from coordinates
 */
export const getMapLink = (lat, lng) => {
  return `https://maps.google.com/?q=${lat},${lng}`;
};

/**
 * Validate email format
 */
export const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate phone number (basic validation)
 */
export const isValidPhone = (phone) => {
  const phoneRegex = /^[0-9+\-\s()]{10,}$/;
  return phoneRegex.test(phone);
};

/**
 * Create emergency message for SOS
 */
export const createSOSMessage = (userName, location) => {
  return `🚨 EMERGENCY ALERT 🚨\n\n${userName} needs help!\n\nLocation: ${getMapLink(location.lat, location.lng)}\nTime: ${new Date().toLocaleString()}\n\nPlease check on them immediately!`;
};

/**
 * Create panic alert message
 */
export const createPanicMessage = (userName, location) => {
  return `⚠️ PANIC ALERT ⚠️\n\n${userName} doesn't feel safe!\n\nImmediate Location: ${getMapLink(location.lat, location.lng)}\nTime: ${new Date().toLocaleString()}\n\nCalling now... Please respond immediately!`;
};

/**
 * Create walk start message
 */
export const createWalkStartMessage = (userName, location) => {
  return `🚶‍♀️ WALK SESSION STARTED\n\n${userName} has started a walk session.\n\nLive Location: ${getMapLink(location.lat, location.lng)}\nStarted: ${new Date().toLocaleString()}\n\nYou'll receive updates every 2 minutes and when the walk ends.`;
};

/**
 * Create location update message
 */
export const createLocationUpdateMessage = (userName, location) => {
  return `📍 LOCATION UPDATE\n\n${userName} is still walking.\n\nCurrent Location: ${getMapLink(location.lat, location.lng)}\nTime: ${new Date().toLocaleString()}`;
};

/**
 * Create walk end message
 */
export const createWalkEndMessage = (userName, location, duration) => {
  return `✅ WALK SESSION ENDED\n\n${userName}'s walk has ended safely.\n\nFinal Location: ${getMapLink(location.lat, location.lng)}\nDuration: ${duration}\nEnded: ${new Date().toLocaleString()}`;
};