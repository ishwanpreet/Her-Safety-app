import React from 'react';
import { Shield, LogOut } from 'lucide-react';

export const Header = ({ user, onLogout }) => {
  const userName =
    user?.displayName ||
    user?.email?.split('@')[0] ||
    'User';

  return (
    <div className="bg-gradient-to-r from-pink-500 to-purple-600 text-white p-4 shadow-lg">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Shield className="w-8 h-8" />
          <div>
            <h1 className="text-2xl font-bold">SheSafe</h1>
            <p className="text-xs text-pink-100">
              Welcome, {userName}
            </p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="hover:bg-white/20 p-2 rounded-lg transition"
        >
          <LogOut className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
