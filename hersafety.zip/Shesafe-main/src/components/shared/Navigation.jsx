import React from 'react';

export const Navigation = ({ activeView, setActiveView }) => {
  const views = ['dashboard', 'contacts', 'heatmap'];
  
  return (
    <div className="bg-white shadow-sm border-b sticky top-0 z-10">
      <div className="max-w-6xl mx-auto flex gap-1 p-2 overflow-x-auto">
        {views.map(view => (
          <button
            key={view}
            onClick={() => setActiveView(view)}
            className={`px-6 py-2 rounded-lg font-medium transition whitespace-nowrap ${
              activeView === view 
                ? 'bg-pink-500 text-white' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {view.charAt(0).toUpperCase() + view.slice(1)}
          </button>
        ))}
      </div>
    </div>
  );
};