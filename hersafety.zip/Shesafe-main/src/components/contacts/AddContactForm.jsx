import React, { useState } from 'react';

export const AddContactForm = ({ onAddContact }) => {
  const [newContact, setNewContact] = useState({ name: '', phone: '', email: '' });

  const handleAdd = () => {
    if (newContact.name && (newContact.phone || newContact.email)) {
      onAddContact(newContact);
      setNewContact({ name: '', phone: '', email: '' });
    }
  };

  return (
    <div className="space-y-4 mb-6 pb-6 border-b">
      <input
        type="text"
        placeholder="Contact Name"
        value={newContact.name}
        onChange={(e) => setNewContact({...newContact, name: e.target.value})}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
      />
      <input
        type="tel"
        placeholder="Phone Number (for calls/SMS)"
        value={newContact.phone}
        onChange={(e) => setNewContact({...newContact, phone: e.target.value})}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
      />
      <input
        type="email"
        placeholder="Email Address (optional)"
        value={newContact.email}
        onChange={(e) => setNewContact({...newContact, email: e.target.value})}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
      />
      <button 
        onClick={handleAdd}
        className="w-full bg-pink-500 text-white py-2 rounded-lg font-semibold hover:bg-pink-600 transition"
      >
        Add Contact
      </button>
    </div>
  );
};