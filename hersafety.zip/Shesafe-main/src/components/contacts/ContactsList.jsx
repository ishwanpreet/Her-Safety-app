import React from 'react';
import { Users } from 'lucide-react';
import { AddContactForm } from './AddContactForm';

export const ContactsList = ({ contacts, onAddContact, onRemoveContact }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-3 mb-6">
        <Users className="w-6 h-6 text-pink-500" />
        <h2 className="text-2xl font-bold text-gray-800">Trusted Contacts</h2>
      </div>

      <AddContactForm onAddContact={onAddContact} />

      <div className="space-y-3">
        {contacts.map(contact => (
          <div key={contact.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-semibold text-gray-800">{contact.name}</p>
              <p className="text-sm text-gray-600">{contact.phone}</p>
              {contact.email && <p className="text-xs text-gray-500">{contact.email}</p>}
            </div>
            <button
              onClick={() => onRemoveContact(contact.id)}
              className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition"
            >
              Remove
            </button>
          </div>
        ))}
        {contacts.length === 0 && (
          <p className="text-center text-gray-500 py-8">No contacts yet. Add your first trusted contact above.</p>
        )}
      </div>
    </div>
  );
};