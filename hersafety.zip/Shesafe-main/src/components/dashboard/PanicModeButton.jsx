import React from 'react';
import { AlertTriangle } from 'lucide-react';

export const PanicModeButton = ({ contacts, location, user, onActivate }) => {
  const handleActivate = () => {
    if (!location) {
      alert('Location not available');
      return;
    }
    
    if (contacts.length === 0) {
      alert('Please add trusted contacts first');
      return;
    }
    
    const userName =
    user?.displayName ||
    user?.email?.split('@')[0] ||
    'User';
    const message = `⚠️ PANIC ALERT ⚠️\n\n${userName} doesn't feel safe!\n\nImmediate Location: https://maps.google.com/?q=${location.lat},${location.lng}\nTime: ${new Date().toLocaleString()}\n\nCalling now... Please respond immediately!`;
    
    contacts.forEach(contact => {
      console.log(`📞 PANIC CALL to ${contact.name} (${contact.phone}): ${message}`);
      console.log(`📱 PANIC SMS to ${contact.name} (${contact.phone}): ${message}`);
    });
    
    alert(`⚠️ PANIC MODE ACTIVATED!\n\nAuto-calling ${contacts.length} contact(s)...\nSMS alerts sent!\n\n${message}`);
    
    if (onActivate) onActivate();
  };

  return (
    <div className="bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl shadow-lg p-6 text-white">
      <div className="flex items-center gap-3 mb-4">
        <AlertTriangle className="w-8 h-8" />
        <div>
          <h2 className="text-2xl font-bold">I Don't Feel Safe</h2>
          <p className="text-sm text-red-100">Instant alert to all emergency contacts</p>
        </div>
      </div>
      <button
        onClick={handleActivate}
        disabled={contacts.length === 0}
        className="w-full bg-white text-red-600 py-4 rounded-lg font-bold text-lg hover:bg-red-50 transition disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {contacts.length > 0 ? 'ACTIVATE PANIC MODE' : 'Add contacts first'}
      </button>
    </div>
  );
};