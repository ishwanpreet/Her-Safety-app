import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { formatTime } from '../../utils/helpers';

export const WalkSession = ({ contacts, location, user }) => {
  const [walkActive, setWalkActive] = useState(false);
  const [walkTimer, setWalkTimer] = useState(0);

  const userName =
    user?.displayName ||
    user?.email?.split('@')[0] ||
    'User';

  useEffect(() => {
    let interval;
    let locationInterval;

    if (walkActive) {
      interval = setInterval(() => setWalkTimer(t => t + 1), 1000);

      locationInterval = setInterval(() => {
        if (navigator.geolocation && location && user) {
          navigator.geolocation.getCurrentPosition((pos) => {
            const newLoc = {
              lat: pos.coords.latitude,
              lng: pos.coords.longitude
            };

            const updateMessage = `📍 LOCATION UPDATE\n\n${userName} is still walking.\n\nCurrent Location: https://maps.google.com/?q=${newLoc.lat},${newLoc.lng}\nTime: ${new Date().toLocaleString()}`;

            contacts.forEach(contact => {
              console.log(
                `📱 Sending to ${contact.name} (${contact.phone || contact.email}): ${updateMessage}`
              );
            });
          });
        }
      }, 120000);
    }

    return () => {
      clearInterval(interval);
      clearInterval(locationInterval);
    };
  }, [walkActive, contacts, location, user, userName]);

  const startWalk = () => {
    if (!location) {
      alert('Location not available');
      return;
    }

    if (contacts.length === 0) {
      alert('Please add trusted contacts first');
      return;
    }

    setWalkActive(true);
    setWalkTimer(0);

    const trackingLink = `https://maps.google.com/?q=${location.lat},${location.lng}`;
    const message = `🚶‍♀️ WALK SESSION STARTED\n\n${userName} has started a walk session.\n\nLive Location: ${trackingLink}\nStarted: ${new Date().toLocaleString()}\n\nYou'll receive updates every 2 minutes and when the walk ends.`;

    contacts.forEach(contact => {
      console.log(
        `📱 Sending to ${contact.name} (${contact.phone || contact.email}): ${message}`
      );
    });

    alert(`Walk started! ${contacts.length} contact(s) notified with your live location.`);
  };

  const stopWalk = () => {
    if (!location) {
      setWalkActive(false);
      return;
    }

    const duration = formatTime(walkTimer);
    const message = `✅ WALK SESSION ENDED\n\n${userName}'s walk has ended safely.\n\nFinal Location: https://maps.google.com/?q=${location.lat},${location.lng}\nDuration: ${duration}\nEnded: ${new Date().toLocaleString()}`;

    contacts.forEach(contact => {
      console.log(
        `📱 Sending to ${contact.name} (${contact.phone || contact.email}): ${message}`
      );
    });

    setWalkActive(false);
    alert(`Walk ended! Duration: ${duration}\nContacts notified of safe arrival.`);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-3 mb-4">
        <Clock className="w-6 h-6 text-purple-500" />
        <h3 className="text-xl font-bold text-gray-800">Walk Session</h3>
      </div>

      {walkActive ? (
        <div>
          <div className="bg-purple-50 rounded-lg p-4 mb-4">
            <div className="flex items-center gap-2 text-green-600 mb-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-semibold">Live Tracking Active</span>
            </div>
            <p className="text-xs text-gray-600">
              {contacts.length} contact(s) receiving updates every 2 min
            </p>
          </div>

          <div className="text-4xl font-bold text-purple-500 mb-4 text-center">
            {formatTime(walkTimer)}
          </div>

          <button
            onClick={stopWalk}
            className="w-full bg-red-500 text-white py-3 rounded-lg font-semibold hover:bg-red-600 transition"
          >
            End Walk & Notify
          </button>
        </div>
      ) : (
        <div>
          <p className="text-gray-600 mb-4">
            Share live location with trusted contacts
          </p>

          <button
            onClick={startWalk}
            disabled={contacts.length === 0}
            className="w-full bg-purple-500 text-white py-3 rounded-lg font-semibold hover:bg-purple-600 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Start Walk
          </button>

          {contacts.length === 0 && (
            <p className="text-sm text-orange-600 mt-2 text-center">
              Add contacts first
            </p>
          )}
        </div>
      )}
    </div>
  );
};
