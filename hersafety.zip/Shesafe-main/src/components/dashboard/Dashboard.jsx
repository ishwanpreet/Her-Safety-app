import React from 'react';
import { PanicModeButton } from './PanicModeButton';
import { WalkSession } from './WalkSession';
import FakeCall from '../call/FakeCall';  // ← default import (no curly braces)

export const Dashboard = ({ contacts, location, user }) => {
  return (
    <div className="space-y-6">
      <PanicModeButton 
        contacts={contacts} 
        location={location} 
        user={user} 
      />

      <div className="grid md:grid-cols-2 gap-6">
        <WalkSession 
          contacts={contacts} 
          location={location} 
          user={user} 
        />
        <FakeCall />  {/* ← No props needed */}
      </div>
    </div>
  );
};