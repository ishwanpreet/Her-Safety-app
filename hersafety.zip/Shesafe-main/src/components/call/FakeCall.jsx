import { useState, useRef } from 'react';
import { FaPhone, FaVolumeUp, FaPhoneSlash, FaMicrophone } from 'react-icons/fa';
import './FakeCall.css';

const FakeCall = () => {
  const [isCalling, setIsCalling] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);

  const audioRef = useRef(null);
  const ringtoneIntervalRef = useRef(null);
  const durationIntervalRef = useRef(null);

  const base64Ringtone =
    'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';

  /* =====================
     RINGTONE BEEP (fallback)
     ===================== */
 const playBeep = () => {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();

  const ring = () => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "sine";
    osc.frequency.value = 440;//iPhone-ish tone

    osc.connect(gain);
    gain.connect(ctx.destination);

    const t = ctx.currentTime;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.6, t + 0.1);
    gain.gain.linearRampToValueAtTime(0, t + 0.8);

    osc.start(t);
    osc.stop(t + 1);
  };

  ring();
  return setInterval(ring, 1200);
};


  /* =====================
     STOP ALL RINGTONE
     ===================== */
  const stopRingtone = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }

    if (ringtoneIntervalRef.current) {
      clearInterval(ringtoneIntervalRef.current);
      ringtoneIntervalRef.current = null;
    }
  };

  /* =====================
     START FAKE CALL
     ===================== */
  const startFakeCall = () => {
    setIsCalling(true);
    setIsAnswered(false);
    setCallDuration(0);

    try {
      audioRef.current = new Audio(base64Ringtone);
      audioRef.current.loop = true;
      audioRef.current.volume = 0.5;

      audioRef.current.play().catch(() => {
        ringtoneIntervalRef.current = playBeep();
      });
    } catch {
      ringtoneIntervalRef.current = playBeep();
    }

    durationIntervalRef.current = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);

    // Auto-answer after 3s
    setTimeout(() => {
      stopRingtone();
      setIsAnswered(true);
    }, 30000);

    // Auto-end after 30s
    setTimeout(endCall, 30000);
  };

  /* =====================
     ANSWER CALL
     ===================== */
  const answerCall = () => {
    stopRingtone();
    setIsAnswered(true);
  };

  /* =====================
     END CALL
     ===================== */
  const endCall = () => {
    stopRingtone();

    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
      durationIntervalRef.current = null;
    }

    setIsCalling(false);
    setIsAnswered(false);
    setCallDuration(0);
  };

  return (
    <div className="fake-call-container">
      <div className="call-header">
        <h3><FaPhone /> Fake Call</h3>
        <p>Simulate a call to appear occupied and safe</p>
      </div>

      {!isCalling ? (
        <button className="start-call-btn" onClick={startFakeCall}>
          <FaPhone /> Start Fake Call
        </button>
      ) : (
        <div className="call-screen">
          <div className="caller-info">
            <div className="caller-avatar">👩</div>
            <div>
              <h3>Mom</h3>
              <p>{isAnswered ? '📞 Connected' : '📳 Ringing...'}</p>
              <p>{callDuration}s</p>
            </div>
          </div>

          {!isAnswered ? (
            <div className="call-actions">
              <button className="answer-btn" onClick={answerCall}>
                <FaPhone /> Answer
              </button>
              <button className="decline-btn" onClick={endCall}>
                <FaPhoneSlash /> Decline
              </button>
            </div>
          ) : (
            <div className="call-controls">
              <button><FaMicrophone /> Mute</button>
              <button><FaVolumeUp /> Speaker</button>
              <button className="end-btn" onClick={endCall}>
                <FaPhoneSlash /> End
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FakeCall;
