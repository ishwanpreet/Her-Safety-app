import React, { useState } from 'react';
import { Shield, AlertCircle, MapPin, AlertTriangle } from 'lucide-react';

export const LoginScreen = ({ onLogin }) => {
  const [loginEmail, setLoginEmail] = useState('');
  const [loginName, setLoginName] = useState('');

  const handleLogin = () => {
    if (loginEmail && loginName) onLogin(loginEmail, loginName);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-8">
          <Shield className="w-16 h-16 mx-auto text-pink-500 mb-4" />
          <h1 className="text-4xl font-bold text-gray-800 mb-2">SheSafe</h1>
          <p className="text-gray-600">Your personal safety companion</p>
        </div>
        
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Enter your name"
            value={loginName}
            onChange={(e) => setLoginName(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
          />
          <input
            type="email"
            placeholder="Enter your email"
            value={loginEmail}
            onChange={(e) => setLoginEmail(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
          />
          <button 
            onClick={handleLogin}
            className="w-full bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 transition"
          >
            Get Started
          </button>
        </div>
        
        <div className="mt-8 space-y-2 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-pink-500" />
            <span>One-tap emergency alerts</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-pink-500" />
            <span>Live location sharing</span>
          </div>
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-pink-500" />
            <span>Community safety heatmap</span>
          </div>
        </div>
      </div>
    </div>
  );
};