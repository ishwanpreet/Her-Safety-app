import React, { useState, useEffect } from 'react';
import { GoogleMap, Marker, InfoWindow } from '@react-google-maps/api';
import { useMaps } from '../../context/MapsContext';

const containerStyle = {
  width: '100%',
  height: '500px',
  borderRadius: '12px'
};

export const GoogleMapView = ({ location, pins, onMapClick, selectedReportLocation }) => {
  const { isLoaded, loadError } = useMaps();
  const [map, setMap] = useState(null);
  const [selectedPin, setSelectedPin] = useState(null);
  const center = location || { lat: 34.0522, lng: -118.2437 };

  useEffect(() => {
    if (map && location) {
      map.panTo(location);
    }
  }, [location, map]);

  if (loadError) {
    return (
      <div className="p-6 bg-red-50 text-red-700 rounded-xl border-2 border-red-300">
        <h3 className="font-bold text-xl mb-2">⚠️ Google Maps Error</h3>
        <p className="text-sm">{loadError.message}</p>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-100 rounded-xl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-700 font-semibold text-lg">Loading Google Maps...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-3 bg-blue-50 border-2 border-blue-300 rounded-lg p-4">
        <p className="text-blue-800 font-semibold text-center">
          🗺️ Click anywhere on the map to select where you want to report an unsafe area
        </p>
      </div>

      <div className="shadow-xl rounded-xl overflow-hidden border-2 border-gray-200">
        <GoogleMap
          mapContainerStyle={containerStyle}
          center={center}
          zoom={15}
          onLoad={(map) => setMap(map)}
          onClick={(e) => {
            const clickedLocation = {
              lat: e.latLng.lat(),
              lng: e.latLng.lng()
            };
            console.log('🗺️ Map clicked at:', clickedLocation);
            onMapClick(clickedLocation);
          }}
          options={{
            zoomControl: true,
            streetViewControl: false,
            mapTypeControl: true,
            fullscreenControl: true,
          }}
        >
          {/* Your Current Location - Blue */}
          {location && (
            <>
              <Marker
                position={location}
                icon={{
                  path: window.google.maps.SymbolPath.CIRCLE,
                  scale: 20,
                  fillColor: '#3B82F6',
                  fillOpacity: 0.2,
                  strokeColor: '#3B82F6',
                  strokeWeight: 2,
                }}
              />
              <Marker
                position={location}
                title="You are here"
                icon={{
                  path: window.google.maps.SymbolPath.CIRCLE,
                  scale: 10,
                  fillColor: '#3B82F6',
                  fillOpacity: 1,
                  strokeColor: '#FFFFFF',
                  strokeWeight: 3,
                }}
              />
            </>
          )}

          {/* Selected Location for Report - Green Pulsing */}
          {selectedReportLocation && (
            <>
              <Marker
                position={selectedReportLocation}
                icon={{
                  path: window.google.maps.SymbolPath.CIRCLE,
                  scale: 25,
                  fillColor: '#10B981',
                  fillOpacity: 0.3,
                  strokeColor: '#10B981',
                  strokeWeight: 2,
                }}
                animation={window.google.maps.Animation.BOUNCE}
              />
              <Marker
                position={selectedReportLocation}
                title="Report location (click below to submit)"
                icon={{
                  path: window.google.maps.SymbolPath.CIRCLE,
                  scale: 12,
                  fillColor: '#10B981',
                  fillOpacity: 1,
                  strokeColor: '#FFFFFF',
                  strokeWeight: 3,
                }}
                animation={window.google.maps.Animation.BOUNCE}
              />
            </>
          )}

          {/* Reported Unsafe Areas */}
          {pins && pins.length > 0 && pins.map((pin, index) => {
            if (!pin.lat || !pin.lng) return null;

            const position = { 
              lat: Number(pin.lat), 
              lng: Number(pin.lng) 
            };

            return (
              <Marker
                key={pin.id}
                position={position}
                onClick={() => setSelectedPin(pin)}
                label={{
                  text: `${index + 1}`,
                  color: 'white',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}
                icon={{
                  path: window.google.maps.SymbolPath.BACKWARD_CLOSED_ARROW,
                  scale: 7,
                  fillColor: 
                    pin.severity === 'high' ? '#DC2626' :
                    pin.severity === 'medium' ? '#F97316' :
                    '#EAB308',
                  fillOpacity: 1,
                  strokeColor: '#FFFFFF',
                  strokeWeight: 2,
                  rotation: 180
                }}
                title={`${pin.severity} risk - ${pin.reason}`}
              />
            );
          })}

          {/* Info Window */}
          {selectedPin && (
            <InfoWindow
              position={{ lat: Number(selectedPin.lat), lng: Number(selectedPin.lng) }}
              onCloseClick={() => setSelectedPin(null)}
            >
              <div className="p-3 max-w-xs">
                <h3 className={`font-bold text-lg mb-2 ${
                  selectedPin.severity === 'high' ? 'text-red-600' :
                  selectedPin.severity === 'medium' ? 'text-orange-600' :
                  'text-yellow-600'
                }`}>
                  {selectedPin.severity?.toUpperCase()} Risk
                </h3>
                <p className="text-sm mb-1"><strong>Reason:</strong> {selectedPin.reason?.replace(/_/g, ' ')}</p>
                {selectedPin.note && <p className="text-sm mb-1"><strong>Note:</strong> {selectedPin.note}</p>}
                <p className="text-xs text-gray-500 mt-2">{new Date(selectedPin.timestamp).toLocaleString()}</p>
              </div>
            </InfoWindow>
          )}
        </GoogleMap>
      </div>

      {/* Legend */}
      <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-2">
        <div className="flex items-center gap-2 bg-blue-50 px-2 py-2 rounded border border-blue-200">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          <span className="text-xs font-medium">You</span>
        </div>
        <div className="flex items-center gap-2 bg-green-50 px-2 py-2 rounded border border-green-200">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-xs font-medium">Selected</span>
        </div>
        <div className="flex items-center gap-2 bg-red-50 px-2 py-2 rounded border border-red-200">
          <div className="w-3 h-3 bg-red-600"></div>
          <span className="text-xs">High ({pins?.filter(p => p.severity === 'high').length || 0})</span>
        </div>
        <div className="flex items-center gap-2 bg-orange-50 px-2 py-2 rounded border border-orange-200">
          <div className="w-3 h-3 bg-orange-500"></div>
          <span className="text-xs">Med ({pins?.filter(p => p.severity === 'medium').length || 0})</span>
        </div>
        <div className="flex items-center gap-2 bg-yellow-50 px-2 py-2 rounded border border-yellow-200">
          <div className="w-3 h-3 bg-yellow-500"></div>
          <span className="text-xs">Low ({pins?.filter(p => p.severity === 'low').length || 0})</span>
        </div>
      </div>
    </div>
  );
};