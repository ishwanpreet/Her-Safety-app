import React from 'react';
import { MapPin } from 'lucide-react';
import { GoogleMapView } from './GoogleMapView';

export const SafetyMap = ({ location, pins, onMapClick, selectedReportLocation }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <MapPin className="w-6 h-6 text-blue-500" />
          <h2 className="text-2xl font-bold text-gray-800">Community Safety Heatmap</h2>
        </div>
        <div className="bg-purple-500 text-white px-4 py-2 rounded-full font-bold">
          {pins?.length || 0} Reports
        </div>
      </div>

      <GoogleMapView 
        location={location} 
        pins={pins} 
        onMapClick={onMapClick}
        selectedReportLocation={selectedReportLocation}
      />
    </div>
  );
};