import React, { useState } from 'react';
import { SafetyMap } from './SafetyMap';
import { ReportForm } from './ReportForm';
import { ReportsList } from './ReportsList';
import { getHeatmapStats } from '../../utils/helpers';

export const Heatmap = ({ location, pins, user, onAddPin }) => {
  const [selectedReportLocation, setSelectedReportLocation] = useState(null);
  const heatmapStats = getHeatmapStats(pins);

  const handleMapClick = (clickedLocation) => {
    console.log('📍 User selected location:', clickedLocation);
    setSelectedReportLocation(clickedLocation);
  };

  const handleSubmitReport = (reportData) => {
    if (!selectedReportLocation) {
      alert('Please select a location on the map first');
      return;
    }

    const newPin = {
      ...reportData,
      lat: selectedReportLocation.lat,
      lng: selectedReportLocation.lng,
      timestamp: new Date().toISOString(),
      reportedBy: 'Anonymous'
    };

    console.log('💾 Submitting report:', newPin);
    onAddPin(newPin);
    setSelectedReportLocation(null);
    alert('✅ Report submitted successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-red-50 rounded-xl p-4 text-center border-2 border-red-200">
          <p className="text-4xl font-bold text-red-600">{heatmapStats.high || 0}</p>
          <p className="text-sm text-gray-600 font-semibold">High Risk</p>
        </div>
        <div className="bg-orange-50 rounded-xl p-4 text-center border-2 border-orange-200">
          <p className="text-4xl font-bold text-orange-600">{heatmapStats.medium || 0}</p>
          <p className="text-sm text-gray-600 font-semibold">Medium Risk</p>
        </div>
        <div className="bg-yellow-50 rounded-xl p-4 text-center border-2 border-yellow-200">
          <p className="text-4xl font-bold text-yellow-600">{heatmapStats.low || 0}</p>
          <p className="text-sm text-gray-600 font-semibold">Low Risk</p>
        </div>
      </div>

      <SafetyMap 
        location={location} 
        pins={pins}
        onMapClick={handleMapClick}
        selectedReportLocation={selectedReportLocation}
      />
      
      <ReportForm 
        onSubmitReport={handleSubmitReport}
        selectedLocation={selectedReportLocation}
        onClearSelection={() => setSelectedReportLocation(null)}
      />
      
      <ReportsList pins={pins} />
    </div>
  );
};