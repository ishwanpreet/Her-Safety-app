import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { getSeverityColor, getSeverityBg } from '../../utils/helpers';

export const ReportsList = ({ pins }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="font-bold text-gray-800 mb-4">Recent Reports ({pins.length})</h3>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {pins.slice().reverse().map(pin => (
          <div key={pin.id} className={`p-4 rounded-lg ${getSeverityBg(pin.severity)}`}>
            <div className="flex items-start gap-3">
              <AlertTriangle className={`w-5 h-5 mt-1 ${getSeverityColor(pin.severity)}`} />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`font-semibold ${getSeverityColor(pin.severity)}`}>
                    {pin.severity.charAt(0).toUpperCase() + pin.severity.slice(1)} Risk
                  </span>
                  <span className="text-xs text-gray-500">• {pin.reason.replace(/_/g, ' ')}</span>
                </div>
                {pin.note && <p className="text-sm text-gray-700 mb-2">{pin.note}</p>}
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <span>📍 {pin.lat.toFixed(4)}, {pin.lng.toFixed(4)}</span>
                  <span>👤Anonymous</span>
                  <span>🕒 {new Date(pin.timestamp).toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
        {pins.length === 0 && (
          <p className="text-center text-gray-500 py-8">No reports yet. Be the first to contribute to community safety.</p>
        )}
      </div>
    </div>
  );
};