import React, { useState } from 'react';
import { MessageSquare, MapPin, X } from 'lucide-react';

export const ReportForm = ({ onSubmitReport, selectedLocation, onClearSelection }) => {
  const [formData, setFormData] = useState({ 
    severity: 'medium', 
    reason: '', 
    note: '' 
  });

  const handleSubmit = () => {
    if (!selectedLocation) {
      alert('⚠️ Please click on the map to select a location first!');
      return;
    }

    if (!formData.reason) {
      alert('⚠️ Please select a reason!');
      return;
    }

    onSubmitReport(formData);
    setFormData({ severity: 'medium', reason: '', note: '' });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="font-bold text-gray-800 flex items-center gap-2 text-xl mb-4">
        <MessageSquare className="w-6 h-6 text-red-600" />
        Report Unsafe Area
      </h3>

      {/* Selected Location Display */}
      {selectedLocation ? (
        <div className="mb-4 bg-green-50 border-2 border-green-300 rounded-lg p-4 relative">
          <button
            onClick={onClearSelection}
            className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 text-green-800 font-semibold mb-2">
            <MapPin className="w-5 h-5" />
            Location Selected
          </div>
          <p className="text-sm text-gray-700 font-mono">
            📍 {selectedLocation.lat.toFixed(6)}, {selectedLocation.lng.toFixed(6)}
          </p>
        </div>
      ) : (
        <div className="mb-4 bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4">
          <p className="text-yellow-800 font-semibold text-center">
            👆 Click on the map above to select where you want to report
          </p>
        </div>
      )}

      <div className="space-y-4">
        <select
          value={formData.severity}
          onChange={(e) => setFormData({...formData, severity: e.target.value})}
          className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
        >
          <option value="low">⚠️ Low Risk</option>
          <option value="medium">⚠️ Medium Risk</option>
          <option value="high">🚨 High Risk</option>
        </select>

        <select
          value={formData.reason}
          onChange={(e) => setFormData({...formData, reason: e.target.value})}
          className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
        >
          <option value="">-- Select reason --</option>
          <option value="poor_lighting">💡 Poor lighting</option>
          <option value="isolated">🏚️ Isolated area</option>
          <option value="harassment">😡 Harassment</option>
          <option value="suspicious_activity">👀 Suspicious activity</option>
          <option value="no_people">👥 No people around</option>
          <option value="other">❓ Other</option>
        </select>

        <textarea
          placeholder="Additional details..."
          value={formData.note}
          onChange={(e) => setFormData({...formData, note: e.target.value})}
          className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 h-24 resize-none"
        />

        <button
          onClick={handleSubmit}
          disabled={!selectedLocation || !formData.reason}
          className="w-full bg-red-600 text-white py-4 rounded-lg font-bold text-lg hover:bg-red-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {!selectedLocation ? '📍 Select location on map first' : '✅ Submit Report'}
        </button>
      </div>
    </div>
  );
};