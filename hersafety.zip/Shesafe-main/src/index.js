import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { MapsProvider } from './context/MapsContext';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <MapsProvider>
      <App />
    </MapsProvider>
  </React.StrictMode>
);