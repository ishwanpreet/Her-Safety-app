import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Import the functions you need from the SDKs you need
//import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "",
  authDomain: "shesafe-a45ad.firebaseapp.com",
  projectId: "shesafe-a45ad",
  storageBucket: "shesafe-a45ad.firebasestorage.app",
  messagingSenderId: "977965119081",
  appId: "1:977965119081:web:6f0f9a920cfa801cbb54f8",
  measurementId: "G-TFK7B1REE2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
//const analytics = getAnalytics(app);

export const auth = getAuth(app);
export const db = getFirestore(app,"yuktha");

export default app;