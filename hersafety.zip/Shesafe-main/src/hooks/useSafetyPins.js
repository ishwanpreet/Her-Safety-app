import { useState, useEffect } from 'react';
import { db } from '../config/firebase';
import { collection, addDoc, query, onSnapshot, orderBy, limit } from 'firebase/firestore';

export const useSafetyPins = () => {
  const [pins, setPins] = useState([]);

  useEffect(() => {
    console.log('🔥 Setting up Firebase listener for safety pins...'); // DEBUG

    const q = query(
      collection(db, 'safetyPins'), 
      orderBy('timestamp', 'desc'),
      limit(100)
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const pinsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      console.log('🔥 Firebase update - Total pins:', pinsData.length); // DEBUG
      console.log('🔥 Pins data:', pinsData); // DEBUG
      
      setPins(pinsData);
    });

    return unsubscribe;
  }, []);

  const addPin = async (pin) => {
    console.log('💾 Adding pin to Firebase:', pin); // DEBUG
    
    try {
      const docRef = await addDoc(collection(db, 'safetyPins'), pin);
      console.log('✅ Pin added successfully with ID:', docRef.id); // DEBUG
    } catch (error) {
      console.error('❌ Error adding pin:', error); // DEBUG
      alert('Error saving report: ' + error.message);
    }
  };

  return { pins, addPin };
};