import { useState, useEffect } from 'react';
import { auth } from '../config/firebase';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut,
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth';

export const useAuth = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const login = async (email, name) => {
    // Create a default password from email (for demo purposes)
    const password = `${email}@SheSafe2024`;
    
    try {
      // Try to create new account first
      const result = await createUserWithEmailAndPassword(auth, email, password);
      
      // Update profile with display name
      await updateProfile(result.user, { 
        displayName: name 
      });
      
      return result.user;
    } catch (error) {
      // If user already exists, try to sign in
      if (error.code === 'auth/email-already-in-use') {
        try {
          const result = await signInWithEmailAndPassword(auth, email, password);
          return result.user;
        } catch (signInError) {
          console.error('Sign in error:', signInError);
          throw new Error('Unable to sign in. Please try a different email.');
        }
      }
      
      // Handle other errors
      console.error('Auth error:', error);
      throw error;
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  return { user, login, logout, loading };
};