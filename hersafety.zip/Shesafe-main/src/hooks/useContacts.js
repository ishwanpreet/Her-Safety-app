import { useState, useEffect } from 'react';
import { db } from '../config/firebase';
import { collection, addDoc, deleteDoc, doc, query, where, onSnapshot } from 'firebase/firestore';

export const useContacts = (userId) => {
  const [contacts, setContacts] = useState([]);

  useEffect(() => {
    if (!userId) return;

    const q = query(collection(db, 'contacts'), where('userId', '==', userId));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const contactsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setContacts(contactsData);
    });

    return unsubscribe;
  }, [userId]);

  const addContact = async (contact) => {
    await addDoc(collection(db, 'contacts'), {
      ...contact,
      userId,
      createdAt: new Date()
    });
  };

  const removeContact = async (contactId) => {
    await deleteDoc(doc(db, 'contacts', contactId));
  };

  return { contacts, addContact, removeContact };
};