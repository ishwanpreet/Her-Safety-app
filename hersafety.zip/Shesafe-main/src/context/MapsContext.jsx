import React, { createContext, useContext } from 'react';
import { useLoadScript } from '@react-google-maps/api';

const MapsContext = createContext();

export const MapsProvider = ({ children }) => {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: "" // Replace with your API key
  });

  return (
    <MapsContext.Provider value={{ isLoaded, loadError }}>
      {children}
    </MapsContext.Provider>
  );
};

export const useMaps = () => {
  const context = useContext(MapsContext);
  if (!context) {
    throw new Error('useMaps must be used within MapsProvider');
  }
  return context;
};