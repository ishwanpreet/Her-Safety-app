import React, { useState } from 'react';
import { useAuth } from './hooks/useAuth';
import { useContacts } from './hooks/useContacts';
import { useSafetyPins } from './hooks/useSafetyPins';
import { useLocation } from './hooks/useLocation';
import { LoginScreen } from './components/auth/LoginScreen';
import { Header } from './components/shared/Header';
import { Navigation } from './components/shared/Navigation';
import { Dashboard } from './components/dashboard/Dashboard';
import { ContactsList } from './components/contacts/ContactsList';
import { Heatmap } from './components/heatmap/Heatmap';

function App() {
  const { user, login, logout } = useAuth();
  const { contacts, addContact, removeContact } = useContacts(user?.uid);
  const { pins, addPin } = useSafetyPins();
  const { location } = useLocation();
  
  const [activeView, setActiveView] = useState('dashboard');

  if (!user) {
    return <LoginScreen onLogin={login} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} onLogout={logout} />
      <Navigation activeView={activeView} setActiveView={setActiveView} />

      <div className="max-w-6xl mx-auto p-4">
        {activeView === 'dashboard' && (
          <Dashboard 
            contacts={contacts}
            location={location}
            user={user}
          />
        )}

        {activeView === 'contacts' && (
          <ContactsList
            contacts={contacts}
            onAddContact={addContact}
            onRemoveContact={removeContact}
          />
        )}

        {activeView === 'heatmap' && (
          <Heatmap
            location={location}
            pins={pins}
            user={user}
            onAddPin={addPin}
          />
        )}
      </div>
    </div>
  );
}

export default App;

